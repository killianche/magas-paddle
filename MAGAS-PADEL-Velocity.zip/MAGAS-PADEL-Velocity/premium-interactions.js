(function () {
  const root = document.documentElement;
  let selection = null;
  let booking = null;

  const $ = (selector, context = document) => context.querySelector(selector);
  const $$ = (selector, context = document) => [...context.querySelectorAll(selector)];

  function showScreen(id) {
    $$(".screen").forEach((screen) => {
      screen.classList.toggle("is-active", screen.id === id);
    });
    $$(".app-nav [data-target]").forEach((item) => {
      item.classList.toggle("is-active", item.dataset.target === id);
    });
    root.classList.toggle("booking-open", id === "book");
    window.scrollTo({ top: 0, behavior: "instant" });
  }

  function selectWithinGroup(button) {
    const group = button.closest("[data-choice-group]");
    if (!group) return;
    $$("[data-choice]", group).forEach((item) => item.classList.remove("is-selected"));
    button.classList.add("is-selected");

    if (group.dataset.choiceGroup === "duration") {
      const duration = Number(button.dataset.value || 1);
      const durationOutput = $("[data-duration-output]");
      if (durationOutput) durationOutput.textContent = `${duration * 60} минут`;
      if (selection) {
        selection.duration = duration;
        updateBookingSummary();
      }
    }
  }

  function updateBookingSummary() {
    const summary = $("[data-booking-summary]");
    const cta = $("[data-confirm-booking]");
    if (!summary || !cta) return;

    if (!selection) {
      summary.textContent = "Выберите свободное время";
      cta.disabled = true;
      cta.textContent = "Продолжить";
      return;
    }

    const durationButton = $('[data-choice-group="duration"] .is-selected');
    const duration = Number(durationButton?.dataset.value || selection.duration || 1);
    selection.duration = duration;
    const end = selection.hour + duration;
    const total = selection.price * duration;
    const date = $('[data-choice-group="date"] .is-selected')?.dataset.full || "Сегодня, 9 сентября";

    summary.textContent = `${date} · ${selection.court} · ${selection.hour}:00–${end}:00`;
    cta.disabled = false;
    cta.textContent = `Забронировать · ${total.toLocaleString("ru-RU")} ₽`;
  }

  function selectSlot(button) {
    if (button.disabled || button.classList.contains("is-busy")) return;
    $$("[data-slot]").forEach((slot) => slot.classList.remove("is-selected"));
    button.classList.add("is-selected");
    selection = {
      court: button.dataset.court || "Корт 1",
      hour: Number(button.dataset.hour || 15),
      price: Number(button.dataset.price || 2500),
      duration: 1,
    };
    updateBookingSummary();
  }

  function openConfirmation() {
    if (!selection) return;
    const modal = $("[data-confirmation]");
    const copy = $("[data-confirmation-copy]");
    if (!modal || !copy) return;

    const duration = selection.duration || 1;
    const end = selection.hour + duration;
    const total = selection.price * duration;
    const date = $('[data-choice-group="date"] .is-selected')?.dataset.full || "Сегодня, 9 сентября";
    copy.textContent = `${date}. ${selection.court}, ${selection.hour}:00–${end}:00. ${total.toLocaleString("ru-RU")} ₽, оплата в клубе.`;
    modal.classList.add("is-open");
  }

  function renderTicket() {
    const container = $("[data-my-content]");
    if (!container || !booking) return;
    container.innerHTML = `
      <article class="confirmed-ticket">
        <div class="confirmed-ticket__media"></div>
        <div class="confirmed-ticket__body">
          <span class="eyebrow">ПОДТВЕРЖДЕНО</span>
          <h2>Ваша игра</h2>
          <p>${booking.date}<br>${booking.court} · ${booking.hour}:00–${booking.end}:00</p>
          <div class="confirmed-ticket__row">
            <strong>${booking.total.toLocaleString("ru-RU")} ₽</strong>
            <span>Оплата в клубе</span>
          </div>
        </div>
      </article>`;
  }

  function confirmBooking() {
    if (!selection) return;
    const duration = selection.duration || 1;
    booking = {
      ...selection,
      date: $('[data-choice-group="date"] .is-selected')?.dataset.full || "Сегодня, 9 сентября",
      end: selection.hour + duration,
      total: selection.price * duration,
    };
    $("[data-confirmation]")?.classList.remove("is-open");
    renderTicket();
    showScreen("my");
  }

  function showToast(message) {
    const toast = $("[data-toast]");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove("is-visible"), 2400);
  }

  document.addEventListener("click", (event) => {
    const button = event.target.closest(
      "[data-target], [data-back], [data-choice], [data-slot], [data-confirm-booking], [data-confirm-final], [data-dismiss], [data-action]"
    );
    if (!button) return;

    if (button.dataset.target) showScreen(button.dataset.target);
    if (button.hasAttribute("data-back")) showScreen(button.dataset.back || "home");
    if (button.hasAttribute("data-choice")) {
      selectWithinGroup(button);
      if (button.closest('[data-choice-group="date"]')) updateBookingSummary();
    }
    if (button.hasAttribute("data-slot")) selectSlot(button);
    if (button.hasAttribute("data-confirm-booking")) openConfirmation();
    if (button.hasAttribute("data-confirm-final")) confirmBooking();
    if (button.hasAttribute("data-dismiss")) {
      button.closest("[data-confirmation]")?.classList.remove("is-open");
    }
    if (button.dataset.action === "join") {
      button.classList.add("is-done");
      button.textContent = "Запрос отправлен";
      showToast("Организатор получил ваш запрос");
    }
    if (button.dataset.action === "notify") {
      button.classList.toggle("is-done");
      showToast(button.classList.contains("is-done") ? "Напоминание включено" : "Напоминание выключено");
    }
  });

  updateBookingSummary();
})();
